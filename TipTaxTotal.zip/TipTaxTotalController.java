/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KeeganKelley
 */
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TipTaxTotalController 
{
    @FXML 
    private Button calcButton;

    @FXML 
    private TextField chargeInput;

    @FXML 
    private Label chargeLabel;

    @FXML 
    private Label tipLabel;
    
    @FXML 
    private Label taxLabel;

    @FXML 
    private Label totalLabel;


    public void initialize() 
    {
    }
    
    public void calculateButtonListener() 
    { 
        final double TIP = 0.18;
        final double TAX = 0.07;
      
        String str = chargeInput.getText();
      
        double chargeInput = Double.parseDouble(str);
        double tipAmount = chargeInput * TIP;
        double taxAmount = chargeInput * TAX;
        double totalAmount = tipAmount + taxAmount + chargeInput;
        
      tipLabel.setText(String.format("Tip: $%,.2f", tipAmount)); 
      taxLabel.setText(String.format("Tax: $%,.2f", taxAmount));
      totalLabel.setText(String.format("Total: $%,.2f", totalAmount));
   }
}